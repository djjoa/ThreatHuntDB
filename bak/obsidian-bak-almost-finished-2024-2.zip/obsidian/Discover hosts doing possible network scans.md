---
id: 525f2ae5-5d11-4404-a0c5-bbd402c57c3f
name: Discover hosts doing possible network scans
description: |
  Looking for high volume queries against a given RemoteIP, per DeviceName, RemotePort and Process.
  Please change the Timestamp window according your preference/objective, as also the subnet ranges that you want to analyze against.
requiredDataConnectors:
  - connectorId: MicrosoftThreatProtection
    dataTypes:
      - DeviceNetworkEvents
query: "```kusto\nlet remotePortCountThreshold = 10; // Please change the min value, for a host reaching out to remote ports on a remote IP, that you consider to be threshold for a suspicious behavior \nDeviceNetworkEvents\n| where Timestamp > ago(1d) and RemoteIP startswith \"172.16\" or RemoteIP startswith \"192.168\" \n| summarize\n    by DeviceName, RemoteIP, RemotePort, InitiatingProcessFileName\n| summarize RemotePortCount=dcount(RemotePort) by DeviceName, RemoteIP, InitiatingProcessFileName\n| where RemotePortCount > remotePortCountThreshold\n```"
---

