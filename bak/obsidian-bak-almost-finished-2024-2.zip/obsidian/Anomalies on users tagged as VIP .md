---
id: 028ac38c-f5a4-483b-a58a-aa83d500bf27
name: Anomalies on users tagged as VIP
description: |
  'Shows all users tagged as VIP in the VIP users watchlist that had anomalies with a score greater than 0.'
requiredDataConnectors:
  - connectorId: BehaviorAnalytics
    dataTypes:
      - BehaviorAnalytics
tactics:
relevantTechniques:
query: |-
  ```kusto
  BehaviorAnalytics
  | where UsersInsights.IsVIPUser == True
  | where InvestigationPriority > 0
  | extend AadUserId = UsersInsights.AccountObjectID
  ```
entityMappings:
  - entityType: Account
    fieldMappings:
      - identifier: AadUserId
        columnName: AadUserId
---

