---
id: 26aebe0d-9a4f-456d-bbb9-9f4c9c5d28ca
name: Cisco Umbrella - DNS Errors.
description: |
  'Shows error DNS requests.'
requiredDataConnectors: []
tactics:
  - InitialAccess
relevantTechniques:
  - T1189
query: |-
  ```kusto
  Cisco_Umbrella
  | where TimeGenerated > ago(24h)
  | where EventType == 'dnslogs'
  | where DnsResponseCodeName != 'NOERROR'
  | extend URLCustomEntity = UrlOriginal
  | extend AccountCustomEntity = Identities
  | extend IPCustomEntity = SrcIpAddr
  ```
---

