---
id: 9644e2ae-07a2-4086-a85a-6ee2bca45f4e
name: AddedCredentialFromContryXAndSigninFromCountryY
description: |
  Added credential from country X and Signed-In from country Y in a pecific time window:
  This query tries to find all applications that credentials were added to them from country X while the application's identity Signed-In from country Y in a specific time window.
requiredDataConnectors:
  - connectorId: MicrosoftThreatProtection
    dataTypes:
      - CloudAppEvents
      - AADSpnSignInEventsBeta
tactics:
  - Persistence
query: |-
  ```kusto
  let timewindow = 1d;
  let addedApps = (
  CloudAppEvents
  | where Application == "Office 365"
  | where ActionType in ("Add service principal credentials.", "Update application - Certificates and secrets management ")
  | project AddedTimestamp = Timestamp , AppName = tostring(RawEventData.Target[3].ID), CountryCode );
  AADSpnSignInEventsBeta
  | join addedApps on $left.ServicePrincipalName == $right.AppName
  | where CountryCode != Country and AddedTimestamp + timewindow > Timestamp
  ```
---

