---
id: 3935b084-2fa1-461a-b920-1e20c1acff7b
name: CiscoISE - Guest authentication failed
description: |
  'Search Guest authentication failed events.'
requiredDataConnectors:
  - connectorId: CiscoISE
    dataTypes:
      - Syslog
tactics:
  - CredentialAccess
query: |-
  ```kusto
  CiscoISEEvent
  | where TimeGenerated > ago(24h)
  | where EventId in ('86009', '86010', '86011', '86012', '86013', '86014', '86015', '86016', '86017', '86018', '86019', '86020')
  | project TimeGenerated, DstUserName, SrcIpAddr, DstIpAddr
  ```
---

