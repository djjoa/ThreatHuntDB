---
id: f5ff5b00-a90e-40b8-b241-9427a8ec5189
name: Dropping payload via certutil
description: |
  BazaCall is a campaign that manipulate users into calling a customer support center, where they are instructed to download an Excel file to unsubscribe from a phony service. When the user opens the Excel file, they are prompted to enable a malicious macro that infects their device with BazaLoader.
  This query hunts for an attacker-created copy of certutil.exe, a legitimate process, which the macro uses to download BazaLoader.
requiredDataConnectors:
  - connectorId: MicrosoftThreatProtection
    dataTypes:
      - DeviceFileEvents
tactics:
  - Initial access
  - Defense evasion
query: |-
  ```kusto
  DeviceFileEvents
  | where InitiatingProcessFileName !~ "certutil.exe"
  | where InitiatingProcessFileName !~ "cmd.exe"
  | where InitiatingProcessCommandLine has_all("-urlcache", "split", "http")
  ```
---

