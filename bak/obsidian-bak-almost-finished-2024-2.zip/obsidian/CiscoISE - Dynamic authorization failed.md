---
id: 98d1384d-5aef-430c-875c-3b4434afb003
name: CiscoISE - Dynamic authorization failed
description: |
  'Search for dynamic authorization failed events.'
requiredDataConnectors:
  - connectorId: CiscoISE
    dataTypes:
      - Syslog
tactics:
  - InitialAccess
query: |-
  ```kusto
  let threshold = 10;
  CiscoISEEvent
  | where TimeGenerated > ago(24h)
  | where EventId == '5417'
  | summarize TotalEvents = count() by SrcIpAddr
  | where TotalEvents > threshold
  ```
---

