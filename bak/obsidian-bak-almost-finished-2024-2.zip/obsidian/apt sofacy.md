---
id: 36a6028d-f977-455f-be11-669e993a25d6
name: apt sofacy
description: |
  Original Sigma Rule: https://github.com/Neo23x0/sigma/blob/master/rules/apt/apt_sofacy.yml.
  Questions via Twitter: @janvonkirchheim.
requiredDataConnectors:
  - connectorId: MicrosoftThreatProtection
    dataTypes:
      - DeviceProcessEvents
query: |-
  ```kusto
  DeviceProcessEvents
  | where Timestamp > ago(7d)
  | where ProcessCommandLine matches regex @'rundll32\.exe %APPDATA%.*\.dat",'
       or ProcessCommandLine matches regex @'rundll32\.exe %APPDATA%.*\.dll",#1'
  | top 100 by Timestamp desc
  ```
---

