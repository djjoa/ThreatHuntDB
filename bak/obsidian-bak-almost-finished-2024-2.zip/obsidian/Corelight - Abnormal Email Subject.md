---
id: e9441d57-39f4-41fb-aaad-d02e47783d1a
name: Corelight - Abnormal Email Subject
description: |
  'Query searches for emails with NON-Ascii characters within the Subject .'
severity: Medium
requiredDataConnectors:
  - connectorId: Corelight
    dataTypes:
      - Corelight_v2_smtp
      - corelight_smtp
tactics:
  - InitialAccess
relevantTechniques:
  - T1566
query: |-
  ```kusto
  corelight_smtp
  | where subject hasprefix @'\=?utf-16'
  ```
entityMappings:
  - entityType: MailMessage
    fieldMappings:
      - identifier: Recipient
        columnName: _to
---

