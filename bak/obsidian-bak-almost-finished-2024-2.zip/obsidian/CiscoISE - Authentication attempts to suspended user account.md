---
id: 72f60667-2a6d-421d-b98d-3d7c3b37a0e5
name: CiscoISE - Authentication attempts to suspended user account
description: |
  'Search authentication attempts to suspended user account.'
requiredDataConnectors:
  - connectorId: CiscoISE
    dataTypes:
      - Syslog
tactics:
  - InitialAccess
  - CredentialAccess
query: |-
  ```kusto
  CiscoISEEvent
  | where TimeGenerated > ago(24h)
  | where EventId == '86014'
  | extend AccountCustomEntity = DstUserName
  ```
---

