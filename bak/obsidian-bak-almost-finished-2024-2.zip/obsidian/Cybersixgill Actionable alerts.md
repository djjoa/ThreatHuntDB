---
id: 532133dd-a8ed-4062-bf0d-f04dc97bb71a
name: Cybersixgill Actionable alerts
description: |
  'View Cybersixgill Actionable alerts for last 30 days'
requiredDataConnectors:
  - connectorId: CybersixgillActionableAlerts
    dataTypes:
      - CyberSixgill_Alerts
query: |-
  ```kusto
  CyberSixgill_Alerts_CL
  | where TimeGenerated > ago(30d)
  ```
---

