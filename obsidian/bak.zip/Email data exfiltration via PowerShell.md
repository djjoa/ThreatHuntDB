---
id: 1115e499-45a0-470c-b0ec-e2f204831341
name: Email data exfiltration via PowerShell
description: |
  Identify email exfiltration conducted by PowerShell.
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceProcessEvents
tactics:
- Exfiltration
query: |   
  DeviceProcessEvents 
  | where FileName =~ 'powershell.exe' 
  | where ProcessCommandLine has_all('Add-PSSnapin', 'Get-Recipient', '-ExpandProperty', 'EmailAddresses', 'SmtpAddress', '-hidetableheaders')

---

