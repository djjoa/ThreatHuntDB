---
id: 54b222c4-0149-421e-9d6d-da66da50495a
name: Detect Modification to System Files or Directories by User Accounts
description: |
  This hunting query searches for modifications to system files or directories by a non system account (User Account). 
tags:
  - Schema: _ASim_FileEvent
    SchemaVersion: 0.2.1
requiredDataConnectors:
  - connectorId: CrowdStrikeFalconEndpointProtection
    dataTypes: 
      - CommonSecurityLog
  - connectorId: MicrosoftThreatProtection
    dataTypes:
      - SecurityAlert
  - connectorId: SentinelOne
    dataTypes:
      - SentinelOne_CL
  - connectorId: VMwareCarbonBlack
    dataTypes:
      - CarbonBlackEvents_CL
  - connectorId: CiscoSecureEndpoint
    dataTypes:
      - CiscoSecureEndpoint_CL
  - connectorId: TrendMicroApexOne
    dataTypes:
      - TMApexOneEvent
  - connectorId: TrendMicroApexOneAma
    dataTypes:
      - TMApexOneEvent
tactics:
  - DefenseEvasion
  - Persistence
  - PrivilegeEscalation
relevantTechniques:
  - T1036
  - T1543
query: |
  // List of system file and directories to monitor
  let systemFilesAndDirs = dynamic([
    "\\Windows\\System32", 
    "//etc", 
    "//bin", 
    "//root", 
    "//lib", 
    "//usr", 
    "//dev"
  ]);
  let systemUserTypes = dynamic([
    'System',
    'Service',
    'Machine',
    'Other'
  ]);
  _ASim_FileEvent
  | where EventType in ('FileCreated' , 'FileModified')
  | where FilePath has_any (systemFilesAndDirs) and ActorUserType !in (systemUserTypes)
  | where isnotempty(ActorUserType)
  | project TimeGenerated, DvcHostname, DvcDomain, User, ActingProcessId, ActingProcessName, CommandLine, FileName, FilePath, Hash, HashType
  | summarize StartTime = max(TimeGenerated), EndTime = min(TimeGenerated) by DvcHostname, DvcDomain, User, ActingProcessId, ActingProcessName, CommandLine, FileName, FilePath, Hash, HashType
  | extend Username = iff(User contains '@', tostring(split(User, '@')[0]), User)
  | extend UPNSuffix = iff(User contains '@', tostring(split(User, '@')[1]), '')
  | extend Username = iff(User contains '\\', tostring(split(User, '\\')[1]), Username)
  | extend NTDomain = iff(User contains '\\', tostring(split(User, '\\')[0]), '')
  | extend Host_0_HostName = DvcHostname
  | extend Host_0_DnsDomain = DvcDomain
  | extend Host_0_NTDomain = NTDomain
  | extend Account_0_Name = Username
  | extend Account_0_UPNSuffix = UPNSuffix
  | extend Account_0_NTDomain = NTDomain
  | extend File_0_Name = FileName
  | extend File_0_Directory = FilePath
  | extend FileHash_0_Algorithm = HashType
  | extend FileHash_0_Value = Hash
  | extend Process_0_ProcessId = ActingProcessId
  | extend Process_0_CommandLine = CommandLine
entityMappings:
  - entityType: Host
    fieldMappings:
      - identifier: HostName
        columnName: DvcHostname
      - identifier: DnsDomain
        columnName: DvcDomain
      - identifier: NTDomain
        columnName: NTDomain
  - entityType: Account
    fieldMappings:
      - identifier: Name
        columnName: Username
      - identifier: UPNSuffix
        columnName: UPNSuffix
      - identifier: NTDomain
        columnName: NTDomain
  - entityType: File
    fieldMappings:
      - identifier: Name
        columnName: FileName
      - identifier: Directory
        columnName: FilePath
  - entityType: FileHash
    fieldMappings:
      - identifier: Algorithm
        columnName: HashType
      - identifier: Value
        columnName: Hash
  - entityType: Process
    fieldMappings:
      - identifier: ProcessId
        columnName: ActingProcessId
      - identifier: CommandLine
        columnName: CommandLine
version: 1.0.0

---

