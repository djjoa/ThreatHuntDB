---
id: 92f02b0b-cd8e-4d49-957c-5ad0ee86da65
name: apt sofacy zebrocy
description: |
  Original Sigma Rule: https://github.com/Neo23x0/sigma/blob/master/rules/apt/apt_sofacy_zebrocy.yml.
  Questions via Twitter: @janvonkirchheim.
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceProcessEvents
query: |
  DeviceProcessEvents
  | where Timestamp > ago(7d)
  | where ProcessCommandLine endswith "cmd.exe /c SYSTEMINFO & TASKLIST"
  | top 100 by Timestamp desc


---

