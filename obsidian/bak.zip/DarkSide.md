---
id: 046d30fc-02b5-4b5f-a244-9c0da92baa5e
name: DarkSide
description: |
  Use this query to look for running DarkSide ransomware behavior in the environment
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceProcessEvents
tactics:
- Ransomware
query: |
  DeviceProcessEvents 
  | where FileName =~ "rundll32.exe" | where ProcessCommandLine matches regex @".dll,#(?:1|3) worker[0-9]\sjob[0-9]-[0-9]{4,}"

---

