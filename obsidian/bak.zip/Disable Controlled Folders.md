---
id: 176cd213-94d7-4984-9b3b-b787ed8a1c55
name: Disable Controlled Folders
description: |
  Prior to deploying Macaw ransomware in an organization, the adversary will disable all controlled folders, which will enable them to be encrypted once the ransomware payload is deployed.
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceProcessEvents
tactics:
- Ransomware
query: |
  DeviceProcessEvents 
  | where InitiatingProcessFileName =~ 'cmd.exe' 
  | where FileName =~ 'powershell.exe' and ProcessCommandLine has('powershell.exe  -command "Set-MpPreference -EnableControlledFolderAccess Disabled"') 

---

