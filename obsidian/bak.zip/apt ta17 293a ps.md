---
id: 6ee810f8-aeca-45c7-81d8-5646ed558961
name: apt ta17 293a ps
description: |
  Original Sigma Rule: https://github.com/Neo23x0/sigma/blob/master/rules/apt/apt_ta17_293a_ps.yml.
  Questions via Twitter: @janvonkirchheim.
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceProcessEvents
query: |
  DeviceProcessEvents 
  | where Timestamp > ago(7d)
  | where ProcessCommandLine =~ "ps.exe -accepteula"
  | top 100 by Timestamp desc 


---

