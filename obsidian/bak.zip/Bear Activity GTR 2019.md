---
id: 376d30db-e3ab-49fb-852a-00d1ade65a54
name: Bear Activity GTR 2019
description: |
  Original Sigma Rule: https://github.com/Neo23x0/sigma/blob/master/rules/apt/apt_bear_activity_gtr19.yml.
  Questions via Twitter: @janvonkirchheim.
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceProcessEvents
query: |
  DeviceProcessEvents 
  | where Timestamp > ago(7d) 
  | where (FileName =~ "xcopy.exe" and ProcessCommandLine has @" /S /E /C /Q /H \") 
       or (FileName =~ "adexplorer.exe" and ProcessCommandLine has @" -snapshot """" c:\users\")
  | top 100 by Timestamp desc


---

