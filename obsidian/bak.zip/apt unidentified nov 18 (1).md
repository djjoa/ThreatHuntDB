---
id: 9bff1151-227c-4581-946d-643266c346a6
name: apt unidentified nov 18 (1)
description: |
  Original Sigma Rule: https://github.com/Neo23x0/sigma/blob/master/rules/apt/apt_unidentified_nov_18.yml.
  Questions via Twitter: @janvonkirchheim.
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceFileEvents
query: |
  DeviceFileEvents  
  | where Timestamp  > ago(7d)
  | where FolderPath has "ds7002.lnk"
  | top 100 by Timestamp desc 


---

