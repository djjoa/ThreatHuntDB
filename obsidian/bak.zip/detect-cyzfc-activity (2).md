---
id: cbfd03f0-34c7-4e03-af37-50eae2892b38
name: detect-cyzfc-activity (2)
description: |
  These queries was originally published in the threat analytics report, Attacks on gov't, think tanks, NGOs.
  As described further in Analysis of cyberattack on U.S. think tanks, non-profits, public sector by unidentified attackers, there was a very large spear-phishing campaign launched in November 2019.
  The attackers would gain access to a target by having the user click on a link to a compromised website and download a .zip archive.
  Once established on a target's device, the attackers used a malicious DLL named cyzfc.dat to execute additional payloads. They would call a function in the malicious DLL via the legitimate Windows process, rundll32.exe, to connect directly to their command-and-control (C2) servers.
  The following queries detect activity associated with the malicious DLL, cyzfc.dat., used in this campaign.
  Reference - https://docs.microsoft.com/windows-server/administration/windows-commands/rundll32
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceProcessEvents
tactics:
- Execution
query: |
  // Query 3: Malicious PowerShell
  DeviceProcessEvents
  | where Timestamp > ago(10d)
  | where ProcessCommandLine contains
  "-noni -ep bypass $zk='JHB0Z3Q9MHgwMDA1ZTJiZTskdmNxPTB4MDAwNjIzYjY7JHRiPSJ"

---

