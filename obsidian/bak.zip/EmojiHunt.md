---
id: 3e246f82-6a80-4cd3-8d4c-8afa2b7451d2
name: EmojiHunt
description: |
  Did you know you can use Emojis in Windows?.
  Read more here: https://davidzych.com/abusing-emoji-in-windows.
  Check-out who in your organization has renamed his or her computer to a Pizza or to a smiling poop.
  You might be amused by the results, or perhaps angry if one of your systems or scripts was broken by this...
  Note: this query will also return some machines with non-English charcters that are not Emojis.
  Credit for this query goes to miflower - thanks for bringing joy to our lives! :).
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceProcessEvents
query: |
  DeviceProcessEvents
  | distinct DeviceName
  | extend fakeescape=replace("%5f", "_", replace("%2d", "-", url_encode(DeviceName)))
  | where fakeescape != DeviceName

---

