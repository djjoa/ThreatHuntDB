---
id: 1174ae5b-8ce9-4321-a4e2-99e5f016beed
name: Base64encodePEFile
description: |
  Finding base64 encoded PE files header seen in the command line parameters.
  Tags: #fileLess  #powershell.
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceProcessEvents
query: |
  DeviceProcessEvents
  | where Timestamp > ago(7d)
  | where ProcessCommandLine contains "TVqQAAMAAAAEAAA"
  | top 1000 by Timestamp


---

