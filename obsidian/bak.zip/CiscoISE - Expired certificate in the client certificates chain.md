---
id: c6ebac93-18af-43e3-b757-d6cb147a74b9
name: CiscoISE - Expired certificate in the client certificates chain
description: |
  'Search for expired certificates in the client certificates chain.'
requiredDataConnectors:
  - connectorId: CiscoISE
    dataTypes:
      - Syslog
query: |
  CiscoISEEvent
  | where TimeGenerated > ago(24h)
  | where EventId == '12516'
  | extend IPCustomEntity = SrcIpAddr

---

