---
id: 64b63d2d-a867-4451-bf74-f2310398498e
name: CiscoISE - Failed login attempts via SSH CLI (users)
description: |
  'Search for Failed login attempts via SSH CLI users.'
requiredDataConnectors:
  - connectorId: CiscoISE
    dataTypes:
      - Syslog
tactics:
  - LateralMovement
query: |
  CiscoISEEvent
  | where TimeGenerated > ago(24h)
  | where EventId in ('60081', '60082')
  | summarize TotalEvents = count() by DstUserName
  | sort by TotalEvents

---

