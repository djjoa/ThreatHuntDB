---
id: 6b2d0b6e-ec4a-4d71-b1cc-dbc470d2b99e
name: c2-bluekeep
description: |
  This query was originally published in the threat analytics report, Exploitation of CVE-2019-0708 (BlueKeep).
  CVE-2019-0708, also known as BlueKeep, is a critical remote code execution vulnerability involving RDP. Soon after its disclosure, the NSA issued a rare advisory about this vulnerability, out of concern that it could be used to quickly spread malware. Attackers have since used this vulnerability to install cryptocurrency miners on targets.
  Microsoft has issued updates for this vulnerability, as well as guidance for protecting operating systems that we no longer support. Microsoft Defender ATP also contains behavioral detections for defending against this threat.
  The following query locates devices that have communicated with attacker infrastructure associated with BlueKeep-related cryptomining.
  References:
  https://nvd.nist.gov/vuln/detail/CVE-2019-0708
  https://www.nsa.gov/News-Features/News-Stories/Article-View/Article/1865726/nsa-cybersecurity-advisory-patch-remote-desktop-services-on-legacy-versions-of/
  https://www.wired.com/story/bluekeep-hacking-cryptocurrency-mining/
  https://portal.msrc.microsoft.com/security-guidance/advisory/CVE-2019-0708
  https://support.microsoft.com/help/4500705/customer-guidance-for-cve-2019-0708
  https://www.microsoft.com/security/blog/2019/11/07/the-new-cve-2019-0708-rdp-exploit-attacks-explained/
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceNetworkEvents
tactics:
- Command and control
query: |
  // Suggest setting Timestamp starting from September 6th
  // when the BlueKeep Metasploit module was released
  let IPs = pack_array("109.176.117.11", "5.100.251.106", 
  "217.23.5.20", "5.135.199.19"); 
  DeviceNetworkEvents
  | where Timestamp > ago(7d) 
  | where RemoteIP in(IPs)


---

