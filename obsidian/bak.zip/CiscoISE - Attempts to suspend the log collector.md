---
id: abea259e-7d56-48d8-ae47-d159929eeed8
name: CiscoISE - Attempts to suspend the log collector
description: |
  'Search for attempts to suspend the log collector.'
requiredDataConnectors:
  - connectorId: CiscoISE
    dataTypes:
      - Syslog
tactics:
  - DefenseEvasion
query: |
  CiscoISEEvent
  | where TimeGenerated > ago(24h)
  | where EventId in ('59206', '59208')
  | extend IPCustomEntity = SrcIpAddr

---

