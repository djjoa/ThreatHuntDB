---
id: 8c54c0f3-fbd4-426b-8f58-363efbdc09fa
name: Cloud Hopper
description: |
  Original Sigma Rule: https://github.com/Neo23x0/sigma/blob/master/rules/apt/apt_cloudhopper.yml.
  Questions via Twitter: @janvonkirchheim.
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceProcessEvents
query: |
  DeviceProcessEvents 
  | where Timestamp > ago(7d)
  | where FileName =~ @"cscript.exe" and ProcessCommandLine has ".vbs /shell "
  | top 100 by Timestamp desc

---

