---
id: 5a540d69-a196-4e1f-9029-df8a100aa4a7
name: Commonality of Operating Systems
description: |
  This query provides the commonality of operating systems seen in the inventory
requiredDataConnectors:
- connectorId: MicrosoftThreatProtection
  dataTypes:
  - DeviceInfo
tactics:
- Resource Development
relevantTechniques: []
query: |
  //
  DeviceInfo
  | summarize arg_max(Timestamp, *) by DeviceId
  | summarize dcount(DeviceId) by OSDistribution

---

